#!/bin/sh

SERVER_PORT=9876
STOP_PORT=9875

BASEDIR=$( cd $(dirname $0) ; pwd -P )
java -cp jetty/classes eu.plumbr.portal.util.OfflineJettyXmlSetup db.xml "${BASEDIR}"
nohup java -XX:+HeapDumpOnOutOfMemoryError \
    -Xmx1024m -XX:MaxPermSize=128m \
    -Dlogback.configurationFile="${BASEDIR}/logback.xml" \
    -Dplumbr.portal.stableBuildLocation="${BASEDIR}/../agent" \
    -Djetty.home="${BASEDIR}/jetty" \
    -DSTOP.PORT=${STOP_PORT} -DSTOP.KEY=StopPlumbr \
    -jar jetty/start.jar db.xml jetty.port=${SERVER_PORT} &
if [ -z ${PLUMBR_SILENT} ]; then
  java -cp jetty/classes eu.plumbr.portal.util.OfflineJettyStartMonitor ${SERVER_PORT}
fi