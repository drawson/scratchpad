#!/bin/sh

STOP_PORT=9875

BASEDIR=$( cd $(dirname $0) ; pwd -P )
java -Djetty.home="${BASEDIR}/jetty" \
    -DSTOP.PORT=${STOP_PORT} -DSTOP.KEY=StopPlumbr -jar jetty/start.jar --stop

