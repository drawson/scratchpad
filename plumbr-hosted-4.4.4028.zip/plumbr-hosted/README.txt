Contents of this package
======================================

agent/ - Contains the Plumbr Agent
server/ - Contains the Plumbr Server
agent/plumbr-agent.zip - Zip file containing the Plumbr Agent and demo
server/start_server.sh, server/start_server.bat - Plumbr Server start scripts
server/stop_server.sh, server/stop_server.sh - Plumbr Server stop scripts
server/plumbr.properties - Plumbr Server properties file (contains SMTP settings and database settings)
server/plumbr.lic - Your Plumbr Server license file
server/logback.xml - Logging configuration (contains log file location and log level settings)
server/jetty/ - Contains the bundled Jetty server with Plumbr Server application included


Server install instructions
======================================

1. If you are on Linux or OS X, run the server/start_server.sh script.
   If you are on Windows, run the server/start_server.bat script.
2. Open http://host-where-you-installed-plumbr-server:9876 (when
   opening it on the same machine: http://localhost:9876).
3. Enter the e-mail and password for the administrator account for the Server
   and optionally login details for an SMTP server which is used to send out
   incident report e-mails.


Using Plumbr Agent with the Server
======================================

1. Unpack the agent/plumbr-agent.zip file.
2. Open the plumbr.properties file in the directory where you unpacked the Agent.
3. Alter the portalServerUrl property value to point to the URL of your Server.
4. Add -javaagent:path/to/agent/plumbr.jar to the startup parameters of the
   application you want to attach Plumbr to.
5. Start the application you want to monitor.


Configuring the Server
======================================

* Changing Server port.

By default the Server uses port 9876. This can be changed by changing the
value of jetty.port property inside start_server.sh or start_server.bat file.

* Changing Server URL.

The Server URL determines the URLs of links inside report e-mails. This should
point to the address that you use to access your Server with, for example:
http://plumbr-server.lan:9876/


Need help?
======================================
Check out the documentation at http://plumbr.eu/support or write to us: support@plumbr.eu